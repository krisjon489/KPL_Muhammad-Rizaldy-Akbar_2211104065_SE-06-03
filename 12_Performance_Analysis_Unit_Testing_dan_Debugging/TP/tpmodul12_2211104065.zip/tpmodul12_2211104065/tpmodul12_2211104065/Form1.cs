﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tpmodul12_2211104065
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Method untuk mencari tanda bilangan
        public string CariTandaBilangan(int a)
        {
            if (a < 0)
                return "Negatif";
            else if (a > 0)
                return "Positif";
            else
                return "Nol";
        }

        // Event handler untuk button click
        private void button1_Click(object sender, EventArgs e)
        {
            // Mendapatkan input dari TextBox dan mengonversi menjadi integer
            int input = Convert.ToInt32(txtInput.Text);

            // Memanggil method CariTandaBilangan dan mendapatkan hasil
            string result = CariTandaBilangan(input);

            // Menampilkan hasil pada Label
            lblOutput.Text = result;
        }

  
        private void txtInput_TextChanged(object sender, EventArgs e)
        {
          
        }


        private void lblOutput_Click(object sender, EventArgs e)
        {

        }
    }
}
