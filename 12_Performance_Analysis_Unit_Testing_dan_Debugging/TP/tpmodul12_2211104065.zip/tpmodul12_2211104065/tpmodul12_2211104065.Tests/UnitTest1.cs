﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using tpmodul12_2211104065;

namespace tpmodul12_2211104065.Tests
{
    [TestClass]
    public class Form1Tests
    {
        // Unit Test untuk memeriksa apakah nilai negatif menghasilkan output "Negatif"
        [TestMethod]
        public void TestCariTandaBilangan_Negatif()
        {
            // Arrange: Membuat objek Form1
            Form1 form = new Form1();

            // Act: Memanggil method CariTandaBilangan dengan input -5
            string result = form.CariTandaBilangan(-5);

            // Assert: Memastikan hasil yang dikembalikan adalah "Negatif"
            Assert.AreEqual("Negatif", result);
        }

        // Unit Test untuk memeriksa apakah nilai positif menghasilkan output "Positif"
        [TestMethod]
        public void TestCariTandaBilangan_Positif()
        {
            // Arrange: Membuat objek Form1
            Form1 form = new Form1();

            // Act: Memanggil method CariTandaBilangan dengan input 5
            string result = form.CariTandaBilangan(5);

            // Assert: Memastikan hasil yang dikembalikan adalah "Positif"
            Assert.AreEqual("Positif", result);
        }

        // Unit Test untuk memeriksa apakah nilai 0 menghasilkan output "Nol"
        [TestMethod]
        public void TestCariTandaBilangan_Nol()
        {
            // Arrange: Membuat objek Form1
            Form1 form = new Form1();

            // Act: Memanggil method CariTandaBilangan dengan input 0
            string result = form.CariTandaBilangan(0);

            // Assert: Memastikan hasil yang dikembalikan adalah "Nol"
            Assert.AreEqual("Nol", result);
        }
    }
}
