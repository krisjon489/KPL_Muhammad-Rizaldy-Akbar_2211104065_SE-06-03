﻿Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports modul12_2211104065 ' Namespace project utama

<TestClass>
Public Class UnitTest1
    <TestMethod>
    Public Sub TestCariNilaiPangkat()
        ' Test b = 0
        Assert.AreEqual(1, Form1.CariNilaiPangkat(5, 0))

        ' Test b < 0
        Assert.AreEqual(-1, Form1.CariNilaiPangkat(5, -2))

        ' Test a > 100 or b > 10
        Assert.AreEqual(-2, Form1.CariNilaiPangkat(101, 5)) ' a > 100
        Assert.AreEqual(-2, Form1.CariNilaiPangkat(5, 11))  ' b > 10

        ' Test overflow
        Assert.AreEqual(-3, Form1.CariNilaiPangkat(100, 100)) ' Overflow case

        ' Test normal
        Assert.AreEqual(125, Form1.CariNilaiPangkat(5, 3)) ' 5^3 = 125
    End Sub
End Class
