﻿Public Class Form1
    ' Mengubah method menjadi static agar bisa diakses dalam unit test
    Public Shared Function CariNilaiPangkat(a As Integer, b As Integer) As Integer
        Try
            ' Aturan i: Jika b = 0, hasil selalu 1
            If b = 0 Then
                Return 1
                ' Aturan ii: Jika b < 0, hasil -1
            ElseIf b < 0 Then
                Return -1
                ' Aturan iii: Jika b > 10 atau a > 100, hasil -2
            ElseIf b > 10 Or a > 100 Then
                Return -2
            End If

            ' Iterasi untuk perhitungan pangkat
            Dim result As Integer = 1
            For i As Integer = 0 To b - 1
                ' Menggunakan pengecekan manual overflow
                If result > Integer.MaxValue \ a Then
                    Throw New OverflowException("Overflow occurred during multiplication.")
                End If
                result *= a
            Next

            Return result
        Catch ex As OverflowException
            ' Jika terjadi overflow, kembalikan -3
            Return -3
        End Try
    End Function

    ' Event handler untuk tombol Calculate (btnCalculate)
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Try
            ' Mengambil nilai dari textbox dan mengonversi menjadi integer
            Dim a As Integer = Convert.ToInt32(txtA.Text)
            Dim b As Integer = Convert.ToInt32(txtB.Text)

            ' Memanggil method CariNilaiPangkat dan menampilkan hasil pada label
            Dim result As Integer = CariNilaiPangkat(a, b)
            lblResult.Text = "Result: " & result.ToString()
        Catch ex As FormatException
            ' Menangani kesalahan jika input tidak valid
            lblResult.Text = "Invalid input!"
        End Try
    End Sub
End Class
